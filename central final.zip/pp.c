#include <stdio.h>
#include <stdlib.h>
#include <string.h>
FILE *btr;
struct Quantum_Libarary
{
  char Book[1000][90];
  int no_of_books;

}c;
void available_Book()
{
  char ch;
  printf("Available books are : \n\n");
  btr = fopen("Central Library.txt", "r");
  {
    if (btr == NULL)
    {
      printf("File is not exist..");
      exit(1);
    }
    while (!feof(btr))
    {
      ch = fgetc(btr);
      printf("%c", ch);
    }
    if (ch == '\0')
    {
      printf("FILE is empty..");
    }

    printf("\n");
    fclose(btr);
  }
}

void main()
{
  int ch;
  char name[35];
  system("cls");
  while (1)
  {
    system("cls");
    printf("\t\t\t\t============ Welcome To Quantum Library ============\n\n");
    printf("\t\tPress [1] For Available Books.\n");
    printf("\t\tPress [2] For Add Books.\n");
    printf("\t\tPress [3] For Creating Numbers Of Files For Library.\n");
    printf("\t\tPress [0] For Exit.\n");
    scanf("%d", &ch);
    switch (ch)
    {
    case 1:
      int s;

      system("cls");
      available_Book();
      printf("Press [0] for Exit.\n\n");

      scanf("%d", &s);
      if (s == 0)
        break;

    case 2:
      int s2;
      while (1)
      {
        fflush(stdin);
        system("cls");
        printf("Enter your name : ");
        gets(name);
        printf("How many books you want to add : ");
        scanf("%d", &c.no_of_books);
        if (c.no_of_books > 1000)
        {
          printf("Out Of Stock.\n");
          printf("Press [1] For continue and [0] for Exit.");
          scanf("%d", &s2);
          if (s2 == 0)
            break;
        }
        for (int i = 0; i < c.no_of_books; i++)
        {
          printf("Enter the name of book : ");
          fflush(stdin);
          gets(c.Book[i]);
        }
        btr = fopen("Central Library.txt", "a");
        fprintf(btr, "\nDate is %s  ", __DATE__);
        fprintf(btr, "Time is %s\n", __TIME__);
        fprintf(btr, "Student name is %s\n", name);
        for (int s = 0; s < c.no_of_books; s++)
        {
          fprintf(btr, "Book name is %s\n", c.Book[s]);
        }
        fclose(btr);
        printf("Book is issued.\n");
        printf("Press [1] For continue and [0] for Exit.");
        scanf("%d", &s2);
        if (s2 == 0)
          break;
      }
      break;
    case 3:
      system("cls");
      FILE *ptr = NULL;
      int s3 = 1, num;
      char content[1000000];
      while (s3 != 0)
      {
        printf("How many files, You want to create :");
        scanf("%d", &num);
        for (int i = 0; i < num; i++)
        {
          printf("Enter the file name : ");
          fflush(stdin);
          gets(name);
          ptr = fopen(name, "a");
          printf("Enter the content : ");
          fflush(stdin);
          gets(content);
          fprintf(ptr, "%s", content);
        }
        printf("Press [1] For continue and [0] for Exit.");
        scanf("%d", &s3);
        if (s3 == 0)
          break;
      }
      break;
    }
    if (ch == 0)
      break;
  }
}
